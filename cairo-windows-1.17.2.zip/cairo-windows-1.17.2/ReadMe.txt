Cairo Graphics:
https://www.cairographics.org/

Precompiled binaries:
https://github.com/preshing/cairo-windows/releases

Headers for Delphi was taken from FreePascal "fpc-cairo" package:
https://freepascal.org/
https://freshports.org/graphics/fpc-cairo